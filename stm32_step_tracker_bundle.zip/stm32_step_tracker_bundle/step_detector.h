#ifndef STEP_DETECTOR_H
#define STEP_DETECTOR_H
#include <stdint.h>

typedef struct {
    float filtered_mag;
    float prev_filtered;
    float baseline;
    uint32_t last_step_ms;
    uint32_t count;
    uint8_t armed;
} StepDetector;
void StepDetector_Init(StepDetector *s);
uint8_t StepDetector_Update(StepDetector *s, float ax_g, float ay_g, float az_g, uint32_t now_ms);
#endif

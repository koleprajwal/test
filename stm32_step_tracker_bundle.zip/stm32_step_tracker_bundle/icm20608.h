#ifndef ICM20608_H
#define ICM20608_H
#include "main.h"
#include <stdint.h>

typedef struct {
    float ax_g, ay_g, az_g;
    float gx_dps, gy_dps, gz_dps;
} ICM20608_Data;

HAL_StatusTypeDef ICM20608_Init(I2C_HandleTypeDef *hi2c);
HAL_StatusTypeDef ICM20608_Read(I2C_HandleTypeDef *hi2c, ICM20608_Data *out);
uint8_t ICM20608_WhoAmI(I2C_HandleTypeDef *hi2c);
#endif

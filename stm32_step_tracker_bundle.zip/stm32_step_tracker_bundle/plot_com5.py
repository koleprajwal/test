"""Live serial plotter for STM32 ICM-20608-G telemetry.
Expected CSV: ms,ax_g,ay_g,az_g,gx_dps,gy_dps,gz_dps,steps
Install: py -m pip install pyserial matplotlib numpy
Run:     py plot_com5.py
"""
import math, time, csv, threading, queue
from collections import deque
import serial
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401

PORT = "COM5"
BAUD = 115200
# Approximate distance per detected step. Measure and change for your own gait.
STRIDE_M = 0.65
# Heuristic vertical change per step when toe pitch is strongly up/down.
STAIR_RISE_M = 0.16
PITCH_THRESHOLD_DEG = 18.0
MAX_POINTS = 3000

q = queue.Queue(maxsize=5000)
stop_event = threading.Event()

def reader():
    try:
        with serial.Serial(PORT, BAUD, timeout=1) as ser:
            ser.reset_input_buffer()
            while not stop_event.is_set():
                raw = ser.readline().decode("ascii", errors="ignore").strip()
                if not raw:
                    continue
                parts = raw.split(",")
                if len(parts) != 8:
                    continue
                try:
                    row = [float(x) for x in parts]
                except ValueError:
                    continue
                try: q.put_nowait(row)
                except queue.Full:
                    pass
    except Exception as e:
        print(f"Serial error on {PORT}: {e}")
        print("Close other serial monitors and verify COM port/baud rate.")

threading.Thread(target=reader, daemon=True).start()

# Samples for sensor plots
T = deque(maxlen=600)
AX = deque(maxlen=600); AY = deque(maxlen=600); AZ = deque(maxlen=600)
GX = deque(maxlen=600); GY = deque(maxlen=600); GZ = deque(maxlen=600)
STEPS = deque(maxlen=600)

# Dead-reckoned illustrative path: heading from gyro z integration; one fixed stride per step.
# This is NOT absolute positioning and will drift. Pitch is approximated from accel only.
px = py = pz = 0.0
heading = 0.0
last_t = None
last_steps = 0
path_x, path_y, path_z = [0.0], [0.0], [0.0]
last_step_index = 0

fig = plt.figure(figsize=(13, 8))
ax3 = fig.add_subplot(221, projection="3d")
ax_acc = fig.add_subplot(222)
ax_gyro = fig.add_subplot(223)
ax_status = fig.add_subplot(224)


def update(_frame):
    global px, py, pz, heading, last_t, last_steps, last_step_index
    changed = False
    while True:
        try: row = q.get_nowait()
        except queue.Empty: break
        ms, ax, ay, az, gx, gy, gz, steps = row
        t = ms / 1000.0
        T.append(t); AX.append(ax); AY.append(ay); AZ.append(az)
        GX.append(gx); GY.append(gy); GZ.append(gz); STEPS.append(int(steps))
        if last_t is not None:
            dt = max(0.0, min(0.1, t-last_t))
            heading += math.radians(gz) * dt
        # Use accelerometer to estimate toe pitch (sensitive to dynamic acceleration).
        pitch = math.degrees(math.atan2(-ax, math.sqrt(ay*ay + az*az) + 1e-9))
        current_steps = int(steps)
        if current_steps > last_steps:
            # One path increment per new step. If multiple counts arrive between plot frames,
            # add each segment at the current estimated heading/pitch.
            for _ in range(min(current_steps-last_steps, 10)):
                px += STRIDE_M * math.cos(heading)
                py += STRIDE_M * math.sin(heading)
                if pitch > PITCH_THRESHOLD_DEG: pz += STAIR_RISE_M
                elif pitch < -PITCH_THRESHOLD_DEG: pz -= STAIR_RISE_M
                path_x.append(px); path_y.append(py); path_z.append(pz)
            last_steps = current_steps
        last_t = t
        changed = True
    if not changed:
        return

    ax3.clear()
    ax3.plot(path_x, path_y, path_z, linewidth=2)
    ax3.scatter([path_x[-1]], [path_y[-1]], [path_z[-1]], s=35)
    ax3.set_title("Estimated 3D path (dead reckoning; not exact position)")
    ax3.set_xlabel("X (m, estimated)"); ax3.set_ylabel("Y (m, estimated)"); ax3.set_zlabel("Z (m, heuristic)")
    ax3.set_box_aspect((1, 1, 0.7))

    ax_acc.clear()
    if T:
        ax_acc.plot(T, AX, label="Ax (g)"); ax_acc.plot(T, AY, label="Ay (g)"); ax_acc.plot(T, AZ, label="Az (g)")
    ax_acc.set_title("Accelerometer"); ax_acc.set_ylabel("g"); ax_acc.legend(loc="upper right", ncols=3, fontsize=8); ax_acc.grid(True)

    ax_gyro.clear()
    if T:
        ax_gyro.plot(T, GX, label="Gx"); ax_gyro.plot(T, GY, label="Gy"); ax_gyro.plot(T, GZ, label="Gz")
    ax_gyro.set_title("Gyroscope (deg/s)"); ax_gyro.set_ylabel("deg/s"); ax_gyro.set_xlabel("Time (s)"); ax_gyro.legend(loc="upper right", ncols=3, fontsize=8); ax_gyro.grid(True)

    ax_status.clear(); ax_status.axis("off")
    ax_status.text(0.03, 0.78, f"COM: {PORT} @ {BAUD}", fontsize=12)
    ax_status.text(0.03, 0.58, f"Steps reported by STM32: {last_steps}", fontsize=12)
    ax_status.text(0.03, 0.38, f"Estimated path endpoint: X={px:.2f} m, Y={py:.2f} m, Z={pz:.2f} m", fontsize=10)
    ax_status.text(0.03, 0.14, "Z and distance are heuristic estimates; gyro yaw drifts without heading reference.", fontsize=9, wrap=True)
    fig.tight_layout()

ani = FuncAnimation(fig, update, interval=100, cache_frame_data=False)
try:
    plt.show()
finally:
    stop_event.set()

#include "icm20608.h"

#define ICM_ADDR       (0x68u << 1) /* AD0 low; use 0x69<<1 if AD0 high */
#define REG_SMPLRT_DIV 0x19
#define REG_CONFIG     0x1A
#define REG_GYRO_CFG   0x1B
#define REG_ACCEL_CFG  0x1C
#define REG_ACCEL_CFG2 0x1D
#define REG_INT_STATUS 0x3A
#define REG_ACCEL_XOUT 0x3B
#define REG_PWR_MGMT_1 0x6B
#define REG_PWR_MGMT_2 0x6C
#define REG_WHO_AM_I   0x75

static HAL_StatusTypeDef wr(I2C_HandleTypeDef *h, uint8_t reg, uint8_t val) {
    return HAL_I2C_Mem_Write(h, ICM_ADDR, reg, I2C_MEMADD_SIZE_8BIT, &val, 1, 20);
}
static HAL_StatusTypeDef rd(I2C_HandleTypeDef *h, uint8_t reg, uint8_t *buf, uint16_t n) {
    return HAL_I2C_Mem_Read(h, ICM_ADDR, reg, I2C_MEMADD_SIZE_8BIT, buf, n, 20);
}
static int16_t s16(uint8_t hi, uint8_t lo) { return (int16_t)(((uint16_t)hi << 8) | lo); }

uint8_t ICM20608_WhoAmI(I2C_HandleTypeDef *hi2c) {
    uint8_t id = 0;
    if (rd(hi2c, REG_WHO_AM_I, &id, 1) != HAL_OK) return 0xFF;
    return id;
}

HAL_StatusTypeDef ICM20608_Init(I2C_HandleTypeDef *hi2c) {
    HAL_StatusTypeDef s;
    /* Reset device. Caller waits at least 100 ms using tick polling before continuing. */
    s = wr(hi2c, REG_PWR_MGMT_1, 0x80); if (s != HAL_OK) return s;
    uint32_t start = HAL_GetTick();
    while ((HAL_GetTick() - start) < 100u) { /* no HAL_Delay */ }
    s = wr(hi2c, REG_PWR_MGMT_1, 0x01); if (s != HAL_OK) return s; /* auto clock */
    s = wr(hi2c, REG_PWR_MGMT_2, 0x00); if (s != HAL_OK) return s; /* all axes on */
    s = wr(hi2c, REG_CONFIG, 0x03); if (s != HAL_OK) return s; /* gyro DLPF ~41 Hz */
    s = wr(hi2c, REG_SMPLRT_DIV, 0x13); if (s != HAL_OK) return s; /* 1 kHz/(1+19)=50 Hz when DLPF enabled */
    s = wr(hi2c, REG_GYRO_CFG, 0x08); if (s != HAL_OK) return s; /* +/-500 dps */
    s = wr(hi2c, REG_ACCEL_CFG, 0x00); if (s != HAL_OK) return s; /* +/-2 g */
    s = wr(hi2c, REG_ACCEL_CFG2, 0x03); if (s != HAL_OK) return s; /* accel DLPF ~44.8 Hz */
    return HAL_OK;
}

HAL_StatusTypeDef ICM20608_Read(I2C_HandleTypeDef *hi2c, ICM20608_Data *o) {
    uint8_t b[14];
    HAL_StatusTypeDef s = rd(hi2c, REG_ACCEL_XOUT, b, sizeof b);
    if (s != HAL_OK) return s;
    int16_t ax=s16(b[0],b[1]), ay=s16(b[2],b[3]), az=s16(b[4],b[5]);
    int16_t gx=s16(b[8],b[9]), gy=s16(b[10],b[11]), gz=s16(b[12],b[13]);
    o->ax_g = (float)ax / 16384.0f;
    o->ay_g = (float)ay / 16384.0f;
    o->az_g = (float)az / 16384.0f;
    o->gx_dps = (float)gx / 65.5f;
    o->gy_dps = (float)gy / 65.5f;
    o->gz_dps = (float)gz / 65.5f;
    return HAL_OK;
}

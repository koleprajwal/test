# STM32F303C8T6 + ICM-20608-G step-count starter bundle

## Contents
- `icm20608.c/.h`: blocking I2C register driver for accel/gyro data.
- `step_detector.c/.h`: filtered acceleration-magnitude peak detector with re-arm and refractory interval.
- `main_user_code.txt`: exact integration instructions for the uploaded CubeMX-generated `main.c`.
- `plot_com5.py`: live COM5 sensor plots and an illustrative 3D step path.

## Critical limitations
1. The 3D path is dead reckoning, not true position. A 6-axis IMU has no absolute heading reference. Gyro yaw drifts; double-integrating acceleration drifts even faster. The plotted Z increment is only a pitch-based heuristic and is not reliable stair-height measurement.
2. The step threshold and 280 ms refractory interval are starting values, not universally correct. Record walking data and tune them.
3. The code calibrates gyro bias while stationary. Proper accelerometer bias/scale calibration needs multiple known orientations. A single static pose cannot fully calibrate all accelerometer axes.
4. The code assumes ICM-20608-G WHO_AM_I is 0xAF and AD0 is low (I2C address 0x68). Verify against your module and register map before debugging further.
5. This code has not been compiled against your exact CubeMX project/device pack or tested on your physical board. Verify it incrementally before wearing it while walking.

## Setup
1. Add `icm20608.c` and `step_detector.c` to `Core/Src`, and headers to `Core/Inc`.
2. Follow `main_user_code.txt` to integrate the code into generated `main.c` USER CODE sections.
3. Correct TIM2 to 50 Hz: under the supplied 72 MHz clock assumptions, use PSC=7199 and ARR=199 (not ARR=99).
4. Wire USB-TTL RX to PA9, GND to GND; optional adapter TX to PA10. Use 3.3 V TTL logic.
5. Build and flash. Keep the IMU motionless during the 8-second gyro calibration at startup.
6. On Windows, install dependencies: `py -m pip install pyserial matplotlib numpy`
7. Close CubeProgrammer/other serial terminals, then run `py plot_com5.py`. Select COM5 and 115200 baud.

## UART format
Each line contains:
`milliseconds,ax_g,ay_g,az_g,gx_dps,gy_dps,gz_dps,step_count`

## Wiring
- ICM VCC and logic level: follow the breakout-board specifications; the bare IC is a low-voltage device.
- ICM GND to STM32 GND.
- ICM SDA to PB7, SCL to PB6 (as configured in uploaded MSP file).
- Ensure I2C pull-ups are present and compatible with the board's logic voltage.
- USB-TTL RX to PA9 (USART1 TX), common GND. Do not connect RS-232 voltage-level hardware.

#include "step_detector.h"
#include <math.h>

#define LP_ALPHA       0.22f
#define PEAK_THRESHOLD 0.18f  /* tune with logged toe-mounted data */
#define REARM_LEVEL    0.07f
#define MIN_STEP_MS    280u   /* limits duplicate impact counts; tune for cadence */

void StepDetector_Init(StepDetector *s) {
    s->filtered_mag=0; s->prev_filtered=0; s->baseline=1.0f;
    s->last_step_ms=0; s->count=0; s->armed=1;
}

uint8_t StepDetector_Update(StepDetector *s, float ax, float ay, float az, uint32_t now) {
    float mag = sqrtf(ax*ax + ay*ay + az*az);
    /* Low-pass magnitude; subtract 1 g baseline to emphasize dynamic movement. */
    s->filtered_mag += LP_ALPHA * (mag - s->filtered_mag);
    float dyn = s->filtered_mag - 1.0f;
    uint8_t hit = 0;

    if (dyn < REARM_LEVEL) s->armed = 1;
    /* Peak is accepted only after a threshold crossing, with refractory time. */
    if (s->armed && s->prev_filtered >= PEAK_THRESHOLD && dyn < s->prev_filtered &&
        (s->last_step_ms == 0u || (now - s->last_step_ms) >= MIN_STEP_MS)) {
        s->count++;
        s->last_step_ms = now;
        s->armed = 0;
        hit = 1;
    }
    s->prev_filtered = dyn;
    return hit;
}
